class Services {
  String title;
  double indicatorValue;

  Services({required this.title, required this.indicatorValue});
}
