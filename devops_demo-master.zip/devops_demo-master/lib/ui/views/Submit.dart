import 'package:flutter/material.dart';
import 'package:devops_demo/database/dao/services.dart';

class Submit extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Text('SUBMITTED SUCCESSFULLY'),
        alignment: Alignment.center,

      )



    );




  }
}